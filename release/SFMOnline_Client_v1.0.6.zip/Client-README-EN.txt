============================================
  SFM Online Client v1.0.0
============================================

[Install]
1. Extract this package and copy BepInEx\plugins\SFMOnline.dll
   into the game's BepInEx\plugins\ folder (overwrite).
2. Launch the game (requires the BepInEx environment, included in the
   integrated package by default).

[Controls]
  F10       Online menu (server list / create-join room / LAN)
  F11       Chat
  F12       General menu (profile / settings / about)
  Alt+F3    Force-reset all control states (HUD button top-right too)
  Shift+F9  Export scene component list to BepInEx\SFMOnline_export.txt

[Login]
1. Password login; after one failed attempt an image captcha is required.
2. Email-code login/registration also requires the image captcha first.

[Online Flow]
1. F10 -> Server List -> choose a relay server.
2. Rooms page: create a room (enter the image captcha) or join one;
   LAN/tunnel rooms are under the "LAN/Tunnel" section.
3. Request control of other players; after they accept, use the advanced
   control panel: vibrator/piston 4 stages, toys (clit/nipple/anal plug/
   blindfold), handcuffs (front/behind/timed), sit-stand toggle, undress
   cycle, exposure, pee/forced climax (water effects), full action list.
4. If anything gets stuck, press Alt+F3 to force-reset everything.

[FAQ]
1. White screen/freeze on launch: first load delays initialization; wait.
2. Empty room list: it refreshes automatically; press "Refresh Room List".
3. Control has no effect: make sure the target accepted control; Alt+F3.

[Contact]
  QQ Group: 1095532943
  Telegram: https://t.me/SFMMM11
  GitHub: https://github.com/wuwupuo/manaka-sfm-mod-
  Server list submission: 3197377739@qq.com

[Disclaimer]
  For technical learning only; not affiliated with the game's rights
  holders. Support the official game. Use at your own risk. No commercial use.

============================================
