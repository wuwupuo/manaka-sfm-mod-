#!/bin/bash
# SFM Online Relay - Linux 启动脚本 v1.0.6
cd "$(dirname "$0")"
python3 -m pip install -r requirements.txt -q
export SFM_CFG="$(pwd)/config.json"
export SFM_STATE="$(pwd)/state.json"
export SFM_CMD="$(pwd)/commands.json"
export SFM_LOG="$(pwd)/relay.log"
export SFM_ADMIN_PORT=7001
echo "Starting relay on port 7000 (UDP 8000) ..."
python3 relay.py &
echo "Starting admin panel on http://127.0.0.1:7001 ..."
python3 admin.py &
wait
