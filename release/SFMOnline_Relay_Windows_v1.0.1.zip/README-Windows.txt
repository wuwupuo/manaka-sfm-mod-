SFM Online Relay - Windows 一键版 v1.0.0
==========================================

【必读】联机服务器在运行过程中必须与总服进行数据共享（master_report），
否则将无法正常开展服务器，无论是否在总服服务器列表中。
config.json 里必须填写 master_report，留空会直接拒绝启动。

【运行】
1. 安装 Python 3.10+（勾选 Add to PATH）
2. 双击 启动联机服.bat
3. 联机服端口 7000；网页后台 http://127.0.0.1:7001

【配置】config.json：端口、secret（务必改）、人数/房间上限、后台账号密码等。
【投稿】想进服务器列表：3197377739@qq.com（见仓库 README 审核机制）。
【开源】https://github.com/wuwupuo/manaka-sfm-mod-
